function calculateFactorial(method) {
    const input = document.getElementById('numberInput').value;
    const number = parseInt(input);
    const resultDiv = document.getElementById('result');

    if (isNaN(number) || number < 0) {
        resultDiv.innerText = "Please enter a valid positive integer.";
        return;
    }

    let result;
    if (method === 'iterative') {
        result = factorialIterative(number);
    } else if (method === 'recursive') {
        result = factorialRecursive(number);
    }

    resultDiv.innerText = `Factorial of ${number} (${method}) is: ${result}`;
}

function factorialIterative(n) {
    let result = 1;
    for (let i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}

function factorialRecursive(n) {
    if (n <= 1) return 1;
    return n * factorialRecursive(n - 1);
}
